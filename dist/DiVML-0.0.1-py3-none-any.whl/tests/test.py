from functools import reduce
import numpy as np
#Minimal example
import sys
import os
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import importlib
import dvml
import dvml.utils

importlib.reload(dvml)
importlib.reload(dvml.utils)
from multiprocessing import Process, freeze_support

if __name__ == '__main__':
    # freeze_support()
    LO = np.array([[1],[0]])
    HI = np.array([[0],[1]])
    Plus = (LO+HI)*(2**-.5)
    Minus = (LO-HI)*(2**-.5)
    RPlu = (LO+1j*HI)*(2**-.5)
    RMin = (LO-1j*HI)*(2**-.5)

    print('Defining measurements...')
    Order = [[LO,HI,Plus,Minus,RPlu,RMin]]*2 #Definion of measurement order, matching data order
    #|01+-RL> state
    ket_gt = reduce(np.kron, [LO, HI])
    rho_gt = ket_gt @ ket_gt.T.conj()
    pis = dvml.utils.make_projector_array(Order, False) #Prepare (Rho)-Pi vect  

    print('Generating data...')
    probs = 1e-6 + np.array([np.abs(pi.T @ ket_gt)**2 for pi in pis]).ravel()
    print(probs)
    my_data = np.array([probs, probs]*64)

    
    R = dvml.Reconstructer(pis, paralelize=True)
    print(R)
    
    outs = R.reconstruct(my_data)
    outs = np.array(outs)
    print(outs.shape)